from flask import Flask, render_template, request, jsonify
from langchain_openai import ChatOpenAI
import httpx
from datetime import datetime

app = Flask(__name__)

# Disable SSL verification for httpx (since you're using self-signed internal cert)
client = httpx.Client(verify=False)

# Initialize LLM
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-w3MhAThbauXLizR2r8cnug",
    http_client=client
)

# In-memory storage for itineraries
itineraries = []

@app.route("/")
def index():
    """Render the main page"""
    return render_template("index.html")

@app.route("/api/travel-options", methods=["POST"])
def get_travel_options():
    """Get AI-powered travel options between source and destination"""
    data = request.json
    source = data.get('source', '')
    destination = data.get('destination', '')
    
    if not source or not destination:
        return jsonify({'error': 'Source and destination are required'}), 400
    
    prompt = f"""Suggest travel options from {source} to {destination}.
    
    For each option, provide:
    1. Mode of transport (Flight/Train/Bus/Car)
    2. Approximate duration
    3. Price range
    4. Best for (budget/comfort/speed)
    
    List at least 3-4 options. Format as a numbered list with clear details."""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        return jsonify({'result': output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/generate-itinerary", methods=["POST"])
def generate_itinerary():
    """Generate detailed day-by-day itinerary using AI"""
    data = request.json
    destination = data.get('destination', '')
    days = data.get('days', 3)
    interests = data.get('interests', 'general sightseeing')
    
    if not destination:
        return jsonify({'error': 'Destination is required'}), 400
    
    prompt = f"""Create a detailed {days}-day itinerary for {destination} focusing on {interests}.
    
    For each day, provide:
    - Morning activities (with timings)
    - Afternoon activities (with timings)
    - Evening activities (with timings)
    - Recommended restaurants/cafes
    - Estimated daily budget in Indian Rupees
    - Travel tips
    
    Format it as Day 1, Day 2, etc. with clear time slots and practical suggestions."""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        return jsonify({'result': output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/search-destinations", methods=["POST"])
def search_destinations():
    """Search destinations using AI"""
    data = request.json
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': 'Query is required'}), 400
    
    prompt = f"""As a travel expert, provide detailed information about {query}.
    
    Include:
    1. Brief description (2-3 sentences)
    2. Best time to visit
    3. Popular attractions (top 5)
    4. Estimated budget range (in Indian Rupees)
    5. Recommended duration
    6. Travel tips
    
    Format the response in a clear, structured way with proper headings."""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        return jsonify({'result': output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/destination-suggestions", methods=["POST"])
def get_destination_suggestions():
    """Get AI-powered destination suggestions based on preferences"""
    data = request.json
    budget = data.get('budget', 'moderate')
    interests = data.get('interests', 'sightseeing')
    season = data.get('season', 'any')
    
    prompt = f"""Suggest 5 travel destinations in India based on:
    - Budget: {budget}
    - Interests: {interests}
    - Best season to visit: {season}
    
    For each destination, provide:
    1. Name and location
    2. Why it matches the criteria
    3. Estimated cost for 3-4 days (in Indian Rupees)
    4. Top 2 must-visit attractions
    5. Best time to visit
    
    Format as a numbered list with clear sections for each destination."""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        return jsonify({'result': output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/itineraries", methods=["GET", "POST"])
def manage_itineraries():
    """Get all itineraries or create a new one"""
    if request.method == "GET":
        return jsonify(itineraries)
    
    elif request.method == "POST":
        data = request.json
        itinerary = {
            'id': len(itineraries) + 1,
            'tripName': data.get('tripName'),
            'destination': data.get('destination'),
            'startDate': data.get('startDate'),
            'endDate': data.get('endDate'),
            'budget': data.get('budget'),
            'notes': data.get('notes'),
            'aiGenerated': data.get('aiGenerated', ''),
            'createdAt': datetime.now().isoformat()
        }
        itineraries.append(itinerary)
        return jsonify(itinerary), 201

@app.route("/api/itineraries/<int:itinerary_id>", methods=["GET", "DELETE"])
def manage_single_itinerary(itinerary_id):
    """Get or delete a specific itinerary"""
    itinerary = next((i for i in itineraries if i['id'] == itinerary_id), None)
    
    if not itinerary:
        return jsonify({'error': 'Itinerary not found'}), 404
    
    if request.method == "GET":
        return jsonify(itinerary)
    
    elif request.method == "DELETE":
        itineraries.remove(itinerary)
        return jsonify({'message': 'Itinerary deleted'}), 200

if __name__ == "__main__":
    app.run(debug=True, port=5000)
