const destinations = [
    {
        id: 1, name: 'Goa', country: 'India', category: 'Beach', budget: 'Moderate', season: 'winter',
        duration: '4-5 days', description: 'Beautiful beaches, vibrant nightlife, Portuguese heritage, and water sports paradise.',
        tags: ['Beach', 'Party', 'Water Sports', 'Heritage']
    },
    {
        id: 2, name: 'Manali', country: 'India', category: 'Mountain', budget: 'Budget', season: 'winter',
        duration: '5-6 days', description: 'Snow-capped mountains, adventure activities, scenic valleys, and Himalayan beauty.',
        tags: ['Mountains', 'Adventure', 'Trekking', 'Snow']
    },
    {
        id: 3, name: 'Jaipur', country: 'India', category: 'Historical', budget: 'Budget', season: 'winter',
        duration: '3-4 days', description: 'Pink City with majestic forts, royal palaces, vibrant bazaars, and rich culture.',
        tags: ['Historical', 'Cultural', 'Architecture', 'Shopping']
    },
    {
        id: 4, name: 'Kerala', country: 'India', category: 'Cultural', budget: 'Moderate', season: 'monsoon',
        duration: '6-7 days', description: 'God\'s Own Country with backwaters, tea plantations, beaches, and Ayurveda.',
        tags: ['Backwaters', 'Nature', 'Ayurveda', 'Beach']
    },
    {
        id: 5, name: 'Ladakh', country: 'India', category: 'Adventure', budget: 'Moderate', season: 'summer',
        duration: '7-8 days', description: 'High-altitude desert with stunning landscapes, Buddhist monasteries, and adventure.',
        tags: ['Mountains', 'Adventure', 'Biking', 'Monastery']
    },
    {
        id: 6, name: 'Udaipur', country: 'India', category: 'City', budget: 'Moderate', season: 'winter',
        duration: '3-4 days', description: 'City of Lakes with romantic palaces, lakeside views, and royal heritage.',
        tags: ['Lakes', 'Heritage', 'Romantic', 'Palace']
    },
    {
        id: 7, name: 'Rishikesh', country: 'India', category: 'Adventure', budget: 'Budget', season: 'spring',
        duration: '3-4 days', description: 'Yoga capital with river rafting, spiritual retreats, and Himalayan views.',
        tags: ['Adventure', 'Spiritual', 'Yoga', 'Rafting']
    },
    {
        id: 8, name: 'Andaman', country: 'India', category: 'Beach', budget: 'Luxury', season: 'winter',
        duration: '5-6 days', description: 'Pristine beaches, crystal clear waters, coral reefs, and marine life.',
        tags: ['Beach', 'Scuba Diving', 'Island', 'Marine Life']
    },
    {
        id: 9, name: 'Varanasi', country: 'India', category: 'Cultural', budget: 'Budget', season: 'winter',
        duration: '2-3 days', description: 'Spiritual capital with ancient ghats, temples, and rich cultural heritage.',
        tags: ['Spiritual', 'Cultural', 'Historical', 'River']
    },
    {
        id: 10, name: 'Darjeeling', country: 'India', category: 'Mountain', budget: 'Moderate', season: 'spring',
        duration: '4-5 days', description: 'Tea gardens, toy train, Kanchenjunga views, and colonial charm.',
        tags: ['Mountains', 'Tea Gardens', 'Heritage', 'Scenic']
    },
    {
        id: 11, name: 'Mumbai', country: 'India', category: 'City', budget: 'Moderate', season: 'winter',
        duration: '3-4 days', description: 'City of dreams with Bollywood, street food, colonial architecture, and beaches.',
        tags: ['City', 'Bollywood', 'Food', 'Beach']
    },
    {
        id: 12, name: 'Hampi', country: 'India', category: 'Historical', budget: 'Budget', season: 'winter',
        duration: '2-3 days', description: 'UNESCO World Heritage Site with ancient ruins, temples, and boulder landscapes.',
        tags: ['Historical', 'Heritage', 'Architecture', 'Ancient']
    }
];

let itineraries = [];
let activeFilters = { search: '', category: '', budget: '', season: '' };

function init() {
    renderDestinations(destinations);
    renderItineraries();
    updateStats();
    setupEventListeners();
    loadItinerariesFromServer();
}

function setupEventListeners() {
    document.querySelectorAll('.filter-chip').forEach(chip => {
        chip.addEventListener('click', function() {
            document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            activeFilters.season = this.dataset.season;
            searchDestinations();
        });
    });

    document.getElementById('searchInput').addEventListener('keyup', function(e) {
        if (e.key === 'Enter') searchDestinations();
    });
}

function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById(tabName).classList.add('active');
}

function renderDestinations(destinationsToRender) {
    const grid = document.getElementById('destinationsGrid');
    if (destinationsToRender.length === 0) {
        grid.innerHTML = '<div class="empty-state"><p>No destinations found. Try adjusting your filters.</p></div>';
        return;
    }
    grid.innerHTML = destinationsToRender.map(dest => `
        <div class="destination-card" onclick="viewDestination(${dest.id})">
            <div class="destination-image">${dest.name.charAt(0)}</div>
            <div class="destination-content">
                <div class="destination-title">${dest.name}</div>
                <div class="destination-info">
                    <span>📍 ${dest.country}</span>
                    <span>⏱️ ${dest.duration}</span>
                    <span>💰 ${dest.budget}</span>
                </div>
                <div class="destination-description">${dest.description}</div>
                <div class="destination-tags">
                    ${dest.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
                <button class="btn btn-small" onclick="event.stopPropagation(); addToItinerary('${dest.name}')">Add to Itinerary</button>
            </div>
        </div>
    `).join('');
}

function searchDestinations() {
    activeFilters.search = document.getElementById('searchInput').value.toLowerCase();
    activeFilters.category = document.getElementById('categoryFilter').value;
    activeFilters.budget = document.getElementById('budgetFilter').value;

    let filtered = destinations.filter(dest => {
        const matchesSearch = !activeFilters.search || 
            dest.name.toLowerCase().includes(activeFilters.search) ||
            dest.description.toLowerCase().includes(activeFilters.search) ||
            dest.tags.some(tag => tag.toLowerCase().includes(activeFilters.search));
        const matchesCategory = !activeFilters.category || dest.category === activeFilters.category;
        const matchesBudget = !activeFilters.budget || dest.budget === activeFilters.budget;
        const matchesSeason = !activeFilters.season || dest.season === activeFilters.season;
        return matchesSearch && matchesCategory && matchesBudget && matchesSeason;
    });

    renderDestinations(filtered);
    updateStats();
}

function viewDestination(id) {
    const dest = destinations.find(d => d.id === id);
    alert(`Viewing ${dest.name}\n\n${dest.description}\n\nBest Time: ${dest.season}\nDuration: ${dest.duration}\nBudget: ${dest.budget}`);
}

function addToItinerary(destinationName) {
    document.getElementById('destination').value = destinationName;
    switchTab('my-trips');
    document.querySelector('[onclick="switchTab(\'my-trips\')"]').click();
    toggleItineraryForm(true);
}

function toggleItineraryForm(show) {
    const form = document.getElementById('addItineraryForm');
    if (show === true) {
        form.classList.remove('hidden');
    } else {
        form.classList.toggle('hidden');
    }
}

async function addItinerary() {
    const tripName = document.getElementById('tripName').value;
    const destination = document.getElementById('destination').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const budget = document.getElementById('budget').value;
    const notes = document.getElementById('notes').value;

    if (!tripName || !destination || !startDate || !endDate) {
        alert('Please fill in all required fields');
        return;
    }

    try {
        const response = await fetch('/api/itineraries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tripName, destination, startDate, endDate, budget, notes })
        });

        if (response.ok) {
            document.getElementById('tripName').value = '';
            document.getElementById('destination').value = '';
            document.getElementById('startDate').value = '';
            document.getElementById('endDate').value = '';
            document.getElementById('budget').value = '';
            document.getElementById('notes').value = '';
            toggleItineraryForm();
            await loadItinerariesFromServer();
        } else {
            alert('Failed to save itinerary');
        }
    } catch (error) {
        alert('Network error. Please try again.');
    }
}

function renderItineraries() {
    const list = document.getElementById('itineraryList');
    const emptyState = document.getElementById('emptyItinerary');

    if (itineraries.length === 0) {
        list.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }

    list.style.display = 'block';
    emptyState.style.display = 'none';

    list.innerHTML = itineraries.map(item => {
        const start = new Date(item.startDate);
        const end = new Date(item.endDate);
        const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;

        return `
            <li class="itinerary-item">
                <div class="itinerary-details">
                    <h4>${item.tripName}</h4>
                    <div class="itinerary-meta">
                        📍 ${item.destination} | 
                        📅 ${item.startDate} to ${item.endDate} (${days} days) | 
                        💰 ₹${item.budget ? parseInt(item.budget).toLocaleString() : 'Not specified'}
                    </div>
                    ${item.notes ? `<p style="margin-top: var(--space-8); color: var(--color-text-secondary);">${item.notes}</p>` : ''}
                </div>
                <div class="itinerary-actions">
                    <button class="btn btn-secondary btn-small" onclick="viewItinerary(${item.id})">View</button>
                    <button class="btn btn-secondary btn-small" onclick="deleteItinerary(${item.id})">Delete</button>
                </div>
            </li>
        `;
    }).join('');
}

function viewItinerary(id) {
    const item = itineraries.find(i => i.id === id);
    const message = item.aiGenerated 
        ? `${item.tripName}\n\n${item.aiGenerated}`
        : `${item.tripName}\n\nDestination: ${item.destination}\nDates: ${item.startDate} to ${item.endDate}\nBudget: ₹${item.budget ? parseInt(item.budget).toLocaleString() : 'Not specified'}\n\nNotes:\n${item.notes || 'No additional notes'}`;
    alert(message);
}

async function deleteItinerary(id) {
    if (!confirm('Are you sure you want to delete this itinerary?')) return;

    try {
        const response = await fetch(`/api/itineraries/${id}`, { method: 'DELETE' });
        if (response.ok) {
            await loadItinerariesFromServer();
        }
    } catch (error) {
        alert('Failed to delete itinerary');
    }
}

function updateStats() {
    const visibleDestinations = destinations.filter(dest => {
        const matchesSearch = !activeFilters.search || 
            dest.name.toLowerCase().includes(activeFilters.search) ||
            dest.description.toLowerCase().includes(activeFilters.search);
        const matchesCategory = !activeFilters.category || dest.category === activeFilters.category;
        const matchesBudget = !activeFilters.budget || dest.budget === activeFilters.budget;
        const matchesSeason = !activeFilters.season || dest.season === activeFilters.season;
        return matchesSearch && matchesCategory && matchesBudget && matchesSeason;
    });

    document.getElementById('destinationCount').textContent = visibleDestinations.length;
    document.getElementById('itineraryCount').textContent = itineraries.length;
    const uniqueCountries = new Set(destinations.map(d => d.country));
    document.getElementById('countriesCount').textContent = uniqueCountries.size;
}

// AI Functions
function showLoading(elementId) {
    document.getElementById(elementId).innerHTML = `
        <div class="loading">
            <div class="spinner"></div>
            <p>AI is thinking...</p>
        </div>
    `;
}

function showError(elementId, message) {
    document.getElementById(elementId).innerHTML = `<div class="error">⚠️ ${message}</div>`;
}

async function getTravelOptions() {
    const source = document.getElementById('travelSource').value.trim();
    const destination = document.getElementById('travelDestination').value.trim();
    
    if (!source || !destination) {
        showError('travelResult', 'Please enter both source and destination');
        return;
    }

    showLoading('travelResult');

    try {
        const response = await fetch('/api/travel-options', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ source, destination })
        });

        const data = await response.json();
        
        if (response.ok) {
            document.getElementById('travelResult').innerHTML = `<div class="result-box">${data.result}</div>`;
        } else {
            showError('travelResult', data.error || 'Failed to fetch travel options');
        }
    } catch (error) {
        showError('travelResult', 'Network error. Please try again.');
    }
}

async function generateAIItinerary() {
    const destination = document.getElementById('aiDestination').value.trim();
    const days = document.getElementById('days').value;
    const interests = document.getElementById('interests').value.trim() || 'general sightseeing';
    
    if (!destination) {
        showError('aiResult', 'Please enter a destination');
        return;
    }

    showLoading('aiResult');

    try {
        const response = await fetch('/api/generate-itinerary', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ destination, days, interests })
        });

        const data = await response.json();
        
        if (response.ok) {
            const escapedResult = data.result.replace(/`/g, '\\`').replace(/\$/g, '\\$');
            document.getElementById('aiResult').innerHTML = `
                <div class="result-box">${data.result}</div>
                <button class="btn btn-secondary" style="margin-top: var(--space-16);" 
                        onclick="saveAIItinerary('${destination}', ${days}, \`${escapedResult}\`)">
                    💾 Save This Itinerary
                </button>
            `;
        } else {
            showError('aiResult', data.error || 'Failed to generate itinerary');
        }
    } catch (error) {
        showError('aiResult', 'Network error. Please try again.');
    }
}

async function searchDestinationsAI() {
    const query = document.getElementById('searchQuery').value.trim();
    
    if (!query) {
        showError('searchResult', 'Please enter a search query');
        return;
    }

    showLoading('searchResult');

    try {
        const response = await fetch('/api/search-destinations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query })
        });

        const data = await response.json();
        
        if (response.ok) {
            document.getElementById('searchResult').innerHTML = `<div class="result-box">${data.result}</div>`;
        } else {
            showError('searchResult', data.error || 'Failed to search destinations');
        }
    } catch (error) {
        showError('searchResult', 'Network error. Please try again.');
    }
}

async function getDestinationSuggestions() {
    const budget = document.getElementById('suggestionBudget').value;
    const interests = document.getElementById('suggestionInterests').value.trim() || 'general travel';
    const season = document.getElementById('suggestionSeason').value;

    showLoading('suggestionsResult');

    try {
        const response = await fetch('/api/destination-suggestions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ budget, interests, season })
        });

        const data = await response.json();
        
        if (response.ok) {
            document.getElementById('suggestionsResult').innerHTML = `<div class="result-box">${data.result}</div>`;
        } else {
            showError('suggestionsResult', data.error || 'Failed to get suggestions');
        }
    } catch (error) {
        showError('suggestionsResult', 'Network error. Please try again.');
    }
}

async function saveAIItinerary(destination, days, aiGenerated) {
    const tripName = `${destination} - ${days} Day Trip`;
    const today = new Date().toISOString().split('T')[0];
    
    try {
        const response = await fetch('/api/itineraries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                tripName, destination, startDate: today, endDate: today, 
                budget: 0, notes: 'AI Generated Itinerary', aiGenerated 
            })
        });

        if (response.ok) {
            alert('✅ Itinerary saved successfully!');
            switchTab('my-trips');
            document.querySelector('[onclick="switchTab(\'my-trips\')"]').click();
            await loadItinerariesFromServer();
        }
    } catch (error) {
        alert('❌ Failed to save itinerary');
    }
}

async function loadItinerariesFromServer() {
    try {
        const response = await fetch('/api/itineraries');
        const serverItineraries = await response.json();
        itineraries = serverItineraries;
        renderItineraries();
        updateStats();
    } catch (error) {
        console.error('Failed to load itineraries from server:', error);
    }
}

init();
