from flask import Flask, render_template, request, jsonify
from langchain_openai import ChatOpenAI
import httpx
from datetime import datetime

app = Flask(__name__)

# Disable SSL verification for httpx (since you're using self-signed internal cert)
client = httpx.Client(verify=False)

# Initialize LLM
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-w3MhAThbauXLizR2r8cnug",
    http_client=client
)

# In-memory storage for itineraries
itineraries = []

def clean_markdown_formatting(text):
    """Remove markdown formatting symbols from text"""
    import re
    
    # Remove markdown headers (# ## ###)
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)
    
    # Remove bold/italic markers (* ** _)
    text = re.sub(r'\*{1,2}([^*]+)\*{1,2}', r'\1', text)
    text = re.sub(r'_{1,2}([^_]+)_{1,2}', r'\1', text)
    
    # Remove trailing questions/recommendations
    lines = text.split('\n')
    filtered_lines = []
    for line in lines:
        line = line.strip()
        if line and not (line.startswith('Would you like') or line.startswith('Do you want') or line.startswith('Need more')):
            filtered_lines.append(line)
    
    # Clean up extra whitespace
    text = '\n'.join(filtered_lines)
    text = re.sub(r'\n\s*\n', '\n\n', text)
    text = text.strip()
    
    return text

@app.route("/")
def index():
    """Render the main page"""
    return render_template("index.html")

@app.route("/Image/<filename>")
def serve_image(filename):
    """Serve images from the Image folder"""
    from flask import send_from_directory
    import os
    return send_from_directory(os.path.join(app.root_path, 'Image'), filename)

@app.route("/api/travel-options", methods=["POST"])
def get_travel_options():
    """Get AI-powered travel options between source and destination"""
    data = request.json
    source = data.get('source', '')
    destination = data.get('destination', '')
    
    if not source or not destination:
        return jsonify({'error': 'Source and destination are required'}), 400
    
    prompt = f"""Suggest travel options from {source} to {destination}.
    
    MANDATORY: For each option, you MUST provide these exact details in this order:
    1. Mode of Transport: [Flight/Train/Bus/Car/etc.]
    2. Approximate Duration: [time in hours or minutes]
    3. Price Range: [cost in Indian Rupees with ₹ symbol]
    4. Best for: [budget/comfort/speed/adventure]
    5. Additional details (operators, routes, etc.)
    
    IMPORTANT FORMATTING RULES:
    - Start each option with: "1. Flight" or "2. Train" etc.
    - Always include "Price Range: ₹X - ₹Y" for every option
    - Use bullet points (-) for sub-details
    - Provide at least 4 different transport options
    
    Example format:
    1. Flight
    - Mode of Transport: Airplane
    - Approximate Duration: 1-1.5 hours
    - Price Range: ₹2,500 - ₹8,000
    - Best for: Speed and comfort
    - Airlines: IndiGo, Vistara, Air India"""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        # Clean markdown formatting
        cleaned_output = clean_markdown_formatting(output)
        return jsonify({'result': cleaned_output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/generate-itinerary", methods=["POST"])
def generate_itinerary():
    """Generate detailed day-by-day itinerary using AI"""
    data = request.json
    destination = data.get('destination', '')
    days = data.get('days', 3)
    interests = data.get('interests', 'general sightseeing')
    
    if not destination:
        return jsonify({'error': 'Destination is required'}), 400
    prompt = f"""Create a detailed {days}-day itinerary for {destination} focusing on {interests}.
    
    FORMATTING REQUIREMENTS:
    - Use "Day 1:", "Day 2:", etc. as clear headers
    - Structure each day with specific time slots
    - Always write "Travel Tips:" (not "Tip: s:" or similar)
    - Provide complete, helpful sentences for all sections
    
    For each day, provide:
    - Morning (8:00 AM - 12:00 PM): [activities with specific timings]
    - Afternoon (12:00 PM - 5:00 PM): [activities with specific timings]
    - Evening (5:00 PM - 9:00 PM): [activities with specific timings]
    - Recommended Restaurants: [specific restaurant names and cuisines]
    - Daily Budget: ₹[amount range] per person
    - Travel Tips: [practical advice, transportation, what to carry, etc.]
    
    Make sure all sections are complete with proper formatting and no truncated text."""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        # Clean markdown formatting
        cleaned_output = clean_markdown_formatting(output)
        return jsonify({'result': cleaned_output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/search-destinations", methods=["POST"])
def search_destinations():
    """Search destinations using AI"""
    data = request.json
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': 'Query is required'}), 400
    
    prompt = f"""As a travel expert, provide detailed information about {query}.
    
    Include:
    1. Brief description (2-3 sentences)
    2. Best time to visit
    3. Popular attractions (top 5)
    4. Estimated budget range (in Indian Rupees)
    5. Recommended duration
    6. Travel tips
      Format the response in a clear, structured way with proper headings."""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        # Clean markdown formatting
        cleaned_output = clean_markdown_formatting(output)
        return jsonify({'result': cleaned_output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/destination-suggestions", methods=["POST"])
def get_destination_suggestions():
    """Get AI-powered destination suggestions based on preferences"""
    data = request.json
    budget = data.get('budget', 'moderate')
    interests = data.get('interests', 'sightseeing')
    season = data.get('season', 'any')
    
    prompt = f"""Suggest 5 travel destinations in India based on:
    - Budget: {budget}
    - Interests: {interests}
    - Best season to visit: {season}
    
    For each destination, provide:
    1. Name and location
    2. Why it matches the criteria
    3. Estimated cost for 3-4 days (in Indian Rupees)
    4. Top 2 must-visit attractions
    5. Best time to visit
      Format as a numbered list with clear sections for each destination."""
    
    try:
        response = llm.invoke(prompt)
        output = getattr(response, 'content', str(response))
        # Clean markdown formatting
        cleaned_output = clean_markdown_formatting(output)
        return jsonify({'result': cleaned_output})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/api/itineraries", methods=["GET", "POST"])
def manage_itineraries():
    """Get all itineraries or create a new one"""
    if request.method == "GET":
        return jsonify(itineraries)
    
    elif request.method == "POST":
        data = request.json
        itinerary = {
            'id': len(itineraries) + 1,
            'tripName': data.get('tripName'),
            'destination': data.get('destination'),
            'startDate': data.get('startDate'),
            'endDate': data.get('endDate'),
            'budget': data.get('budget'),
            'notes': data.get('notes'),
            'aiGenerated': data.get('aiGenerated', ''),
            'createdAt': datetime.now().isoformat()
        }
        itineraries.append(itinerary)
        return jsonify(itinerary), 201

@app.route("/api/itineraries/<int:itinerary_id>", methods=["GET", "DELETE"])
def manage_single_itinerary(itinerary_id):
    """Get or delete a specific itinerary"""
    itinerary = next((i for i in itineraries if i['id'] == itinerary_id), None)
    
    if not itinerary:
        return jsonify({'error': 'Itinerary not found'}), 404
    
    if request.method == "GET":
        return jsonify(itinerary)
    
    elif request.method == "DELETE":
        itineraries.remove(itinerary)
        return jsonify({'message': 'Itinerary deleted'}), 200

if __name__ == "__main__":
    app.run(debug=True, port=5000)
