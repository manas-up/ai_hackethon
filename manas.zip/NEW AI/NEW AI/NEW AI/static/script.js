// Destination images mapping
const destinationImages = {
    'Goa': 'Goa.jpg',
    'Manali': 'manali.webp', 
    'Jaipur': 'Jaipur.webp',
    'Kerala': 'kerala.jpg',
    'Ladakh': 'Ladhak.jpg',
    'Udaipur': 'Udapur.webp',
    'Rishikesh': 'Rishikesh.jpg',
    'Andaman': 'Andman.jpg',
    'Varanasi': 'Varansi.png',
    'Darjeeling': 'Darjaling.jpg',
    'Mumbai': 'mumbai.jpg',
    'Hampi': 'Hampi.jpg'
};

const destinations = [
    {
        id: 1, name: 'Goa', country: 'India', category: 'Beach', budget: 'Moderate', season: 'winter',
        duration: '4-5 days', description: 'Beautiful beaches, vibrant nightlife, Portuguese heritage, and water sports paradise.',
        tags: ['Beach', 'Party', 'Water Sports', 'Heritage']
    },
    {
        id: 2, name: 'Manali', country: 'India', category: 'Mountain', budget: 'Budget', season: 'winter',
        duration: '5-6 days', description: 'Snow-capped mountains, adventure activities, scenic valleys, and Himalayan beauty.',
        tags: ['Mountains', 'Adventure', 'Trekking', 'Snow']
    },
    {
        id: 3, name: 'Jaipur', country: 'India', category: 'Historical', budget: 'Budget', season: 'winter',
        duration: '3-4 days', description: 'Pink City with majestic forts, royal palaces, vibrant bazaars, and rich culture.',
        tags: ['Historical', 'Cultural', 'Architecture', 'Shopping']
    },
    {
        id: 4, name: 'Kerala', country: 'India', category: 'Cultural', budget: 'Moderate', season: 'monsoon',
        duration: '6-7 days', description: 'God\'s Own Country with backwaters, tea plantations, beaches, and Ayurveda.',
        tags: ['Backwaters', 'Nature', 'Ayurveda', 'Beach']
    },
    {
        id: 5, name: 'Ladakh', country: 'India', category: 'Adventure', budget: 'Moderate', season: 'summer',
        duration: '7-8 days', description: 'High-altitude desert with stunning landscapes, Buddhist monasteries, and adventure.',
        tags: ['Mountains', 'Adventure', 'Biking', 'Monastery']
    },
    {
        id: 6, name: 'Udaipur', country: 'India', category: 'City', budget: 'Moderate', season: 'winter',
        duration: '3-4 days', description: 'City of Lakes with romantic palaces, lakeside views, and royal heritage.',
        tags: ['Lakes', 'Heritage', 'Romantic', 'Palace']
    },
    {
        id: 7, name: 'Rishikesh', country: 'India', category: 'Adventure', budget: 'Budget', season: 'spring',
        duration: '3-4 days', description: 'Yoga capital with river rafting, spiritual retreats, and Himalayan views.',
        tags: ['Adventure', 'Spiritual', 'Yoga', 'Rafting']
    },
    {
        id: 8, name: 'Andaman', country: 'India', category: 'Beach', budget: 'Luxury', season: 'winter',
        duration: '5-6 days', description: 'Pristine beaches, crystal clear waters, coral reefs, and marine life.',
        tags: ['Beach', 'Scuba Diving', 'Island', 'Marine Life']
    },
    {
        id: 9, name: 'Varanasi', country: 'India', category: 'Cultural', budget: 'Budget', season: 'winter',
        duration: '2-3 days', description: 'Spiritual capital with ancient ghats, temples, and rich cultural heritage.',
        tags: ['Spiritual', 'Cultural', 'Historical', 'River']
    },
    {
        id: 10, name: 'Darjeeling', country: 'India', category: 'Mountain', budget: 'Moderate', season: 'spring',
        duration: '4-5 days', description: 'Tea gardens, toy train, Kanchenjunga views, and colonial charm.',
        tags: ['Mountains', 'Tea Gardens', 'Heritage', 'Scenic']
    },
    {
        id: 11, name: 'Mumbai', country: 'India', category: 'City', budget: 'Moderate', season: 'winter',
        duration: '3-4 days', description: 'City of dreams with Bollywood, street food, colonial architecture, and beaches.',
        tags: ['City', 'Bollywood', 'Food', 'Beach']
    },
    {
        id: 12, name: 'Hampi', country: 'India', category: 'Historical', budget: 'Budget', season: 'winter',
        duration: '2-3 days', description: 'UNESCO World Heritage Site with ancient ruins, temples, and boulder landscapes.',
        tags: ['Historical', 'Heritage', 'Architecture', 'Ancient']
    }
];

let itineraries = [];

function init() {
    renderDestinations(destinations);
    renderItineraries();
    loadItinerariesFromServer();
}



function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById(tabName).classList.add('active');
}

function renderDestinations(destinationsToRender) {
    const grid = document.getElementById('destinationsGrid');
    grid.innerHTML = destinationsToRender.map(dest => {
        const imageFile = destinationImages[dest.name] || 'Goa.jpg';
        const imagePath = `/Image/${imageFile}`;
        
        return `
        <div class="destination-card">
            <div class="destination-image" style="background-image: url('${imagePath}')">
                <div class="destination-overlay">
                    <span class="destination-name-overlay">${dest.name}</span>
                </div>
            </div>
            <div class="destination-content">
                <div class="destination-title">${dest.name}</div>
                <div class="destination-info">
                    <span>📍 ${dest.country}</span>
                    <span>⏱️ ${dest.duration}</span>
                    <span>💰 ${dest.budget}</span>
                </div>
                <div class="destination-description">${dest.description}</div>
                <div class="destination-tags">
                    ${dest.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
            </div>
        </div>
        `;
    }).join('');
}





function toggleItineraryForm(show) {
    const form = document.getElementById('addItineraryForm');
    if (show === true) {
        form.classList.remove('hidden');
    } else {
        form.classList.toggle('hidden');
    }
}

async function addItinerary() {
    const tripName = document.getElementById('tripName').value;
    const destination = document.getElementById('destination').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const budget = document.getElementById('budget').value;
    const notes = document.getElementById('notes').value;

    if (!tripName || !destination || !startDate || !endDate) {
        alert('Please fill in all required fields');
        return;
    }

    try {
        const response = await fetch('/api/itineraries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tripName, destination, startDate, endDate, budget, notes })
        });

        if (response.ok) {
            document.getElementById('tripName').value = '';
            document.getElementById('destination').value = '';
            document.getElementById('startDate').value = '';
            document.getElementById('endDate').value = '';
            document.getElementById('budget').value = '';
            document.getElementById('notes').value = '';
            toggleItineraryForm();
            await loadItinerariesFromServer();
        } else {
            alert('Failed to save itinerary');
        }
    } catch (error) {
        alert('Network error. Please try again.');
    }
}

function renderItineraries() {
    const list = document.getElementById('itineraryList');
    const emptyState = document.getElementById('emptyItinerary');

    if (itineraries.length === 0) {
        list.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }

    list.style.display = 'block';
    emptyState.style.display = 'none';

    list.innerHTML = itineraries.map(item => {
        const start = new Date(item.startDate);
        const end = new Date(item.endDate);
        const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;

        return `
            <li class="itinerary-item">
                <div class="itinerary-details">
                    <h4>${item.tripName}</h4>
                    <div class="itinerary-meta">
                        📍 ${item.destination} | 
                        📅 ${item.startDate} to ${item.endDate} (${days} days) | 
                        💰 ₹${item.budget ? parseInt(item.budget).toLocaleString() : 'Not specified'}
                    </div>
                    ${item.notes ? `<p style="margin-top: var(--space-8); color: var(--color-text-secondary);">${item.notes}</p>` : ''}
                </div>
                <div class="itinerary-actions">
                    <button class="btn btn-secondary btn-small" onclick="viewItinerary(${item.id})">View</button>
                    <button class="btn btn-secondary btn-small" onclick="deleteItinerary(${item.id})">Delete</button>
                </div>
            </li>
        `;
    }).join('');
}

function viewItinerary(id) {
    const item = itineraries.find(i => i.id === id);
    const message = item.aiGenerated 
        ? `${item.tripName}\n\n${item.aiGenerated}`
        : `${item.tripName}\n\nDestination: ${item.destination}\nDates: ${item.startDate} to ${item.endDate}\nBudget: ₹${item.budget ? parseInt(item.budget).toLocaleString() : 'Not specified'}\n\nNotes:\n${item.notes || 'No additional notes'}`;
    alert(message);
}

async function deleteItinerary(id) {
    if (!confirm('Are you sure you want to delete this itinerary?')) return;

    try {
        const response = await fetch(`/api/itineraries/${id}`, { method: 'DELETE' });
        if (response.ok) {
            await loadItinerariesFromServer();
        }
    } catch (error) {
        alert('Failed to delete itinerary');
    }
}



// AI Functions
function showLoading(elementId) {
    document.getElementById(elementId).innerHTML = `
        <div class="loading">
            <div class="spinner"></div>
            <p>AI is thinking...</p>
        </div>
    `;
}

function showError(elementId, message) {
    document.getElementById(elementId).innerHTML = `<div class="error">⚠️ ${message}</div>`;
}

async function getTravelOptions() {
    const source = document.getElementById('travelSource').value.trim();
    const destination = document.getElementById('travelDestination').value.trim();
    
    if (!source || !destination) {
        showError('travelResult', 'Please enter both source and destination');
        return;
    }

    showLoading('travelResult');

    try {
        const response = await fetch('/api/travel-options', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ source, destination })
        });

        const data = await response.json();
        
        if (response.ok) {
            displayTravelOptions(data.result);
        } else {
            showError('travelResult', data.error || 'Failed to fetch travel options');
        }
    } catch (error) {
        showError('travelResult', 'Network error. Please try again.');
    }
}

function displayTravelOptions(rawText) {
    const lines = rawText.split('\n');
    const options = [];
    let currentOption = null;
    
    for (let line of lines) {
        line = line.trim();
        if (!line) continue;
        
        // Skip summary lines and questions
        if (line.toLowerCase().includes('summary:') || 
            line.toLowerCase().includes('would you like') ||
            line.toLowerCase().includes('fastest:') ||
            line.toLowerCase().includes('cheapest:') ||
            line.toLowerCase().includes('most comfortable:') ||
            line.toLowerCase().includes('most flexible:')) {
            continue;
        }
        
        // Check if it's a new transportation mode (starts with number)
        if (line.match(/^\d+\.\s*(\w+)/)) {
            // Save previous option if exists
            if (currentOption) {
                options.push(currentOption);
            }
            
            // Extract mode name (Flight, Train, Bus, etc.)
            const modeMatch = line.match(/^\d+\.\s*(.+)/);
            const mode = modeMatch ? modeMatch[1].trim() : line;
            
            currentOption = {
                mode: mode,
                icon: getTransportIcon(mode),
                details: [],
                duration: '',
                priceRange: '',
                bestFor: ''
            };        } else if (currentOption && line.startsWith('-')) {
            // Parse specific details
            const detail = line.substring(1).trim();
            
            if (detail.toLowerCase().includes('duration:') || 
                detail.toLowerCase().includes('approximate duration:')) {
                currentOption.duration = detail;
            } else if (detail.toLowerCase().includes('price range:') || 
                       detail.toLowerCase().includes('estimated cost:') ||
                       detail.toLowerCase().includes('cost:') ||
                       detail.includes('₹')) {
                currentOption.priceRange = detail;
            } else if (detail.toLowerCase().includes('best for:')) {
                currentOption.bestFor = detail;
            } else if (detail.toLowerCase().includes('mode of transport:')) {
                currentOption.details.push(detail);
            } else {
                // Add other details
                currentOption.details.push(detail);
            }
        } else if (currentOption && line && !line.toLowerCase().includes('summary')) {
            // Add any other relevant info (but skip summary section)
            currentOption.details.push(line);
        }
    }
      // Don't forget the last option
    if (currentOption) {
        options.push(currentOption);
    }
    
    // Post-process to ensure each option has a price range
    options.forEach(option => {
        if (!option.priceRange) {
            // Look for price information in details
            for (let detail of option.details) {
                if (detail.includes('₹') || detail.toLowerCase().includes('price') || 
                    detail.toLowerCase().includes('cost') || detail.toLowerCase().includes('rupees')) {
                    option.priceRange = detail;
                    // Remove from details to avoid duplication
                    option.details = option.details.filter(d => d !== detail);
                    break;
                }
            }
            
            // If still no price range found, add a default message
            if (!option.priceRange) {
                option.priceRange = "Price Range: Contact for pricing";
            }
        }
    });
    
    // Generate HTML for sections
    let html = '<div class="travel-options-container">';
    
    options.forEach(option => {        html += `
        <div class="travel-option-section">
            <div class="transport-header">
                <span class="transport-icon">${option.icon}</span>
                <h3 class="transport-title">${getTransportName(option.mode)}</h3>
            </div>
            <div class="transport-details">
                ${option.duration ? `<p class="detail-item duration">${option.duration}</p>` : ''}
                ${option.priceRange ? `<p class="detail-item price-range">${option.priceRange}</p>` : ''}
                ${option.bestFor ? `<p class="detail-item best-for">${option.bestFor}</p>` : ''}
                ${option.details.map(detail => `<p class="detail-item">${detail}</p>`).join('')}
            </div>
        </div>
        `;
    });
    
    html += '</div>';
    
    document.getElementById('travelResult').innerHTML = html;
}

function getTransportIcon(mode) {
    const modeStr = mode.toLowerCase();
    if (modeStr.includes('flight') || modeStr.includes('airplane') || modeStr.includes('air')) return '✈️';
    if (modeStr.includes('train') || modeStr.includes('railway')) return '🚂';
    if (modeStr.includes('bus')) return '🚌';
    if (modeStr.includes('car') || modeStr.includes('drive') || modeStr.includes('self')) return '🚗';
    if (modeStr.includes('bike') || modeStr.includes('motorcycle')) return '🏍️';
    if (modeStr.includes('ship') || modeStr.includes('ferry')) return '🚢';
    if (modeStr.includes('taxi') || modeStr.includes('cab')) return '🚕';
    return '🚗'; // Default
}

function getTransportName(mode) {
    const modeStr = mode.toLowerCase();
    if (modeStr.includes('flight') || modeStr.includes('airplane') || modeStr.includes('air')) return 'Flight';
    if (modeStr.includes('train') || modeStr.includes('railway')) return 'Train';
    if (modeStr.includes('bus')) return 'Bus';
    if (modeStr.includes('car') || modeStr.includes('drive') || modeStr.includes('self')) return 'Car';
    if (modeStr.includes('bike') || modeStr.includes('motorcycle')) return 'Bike';
    if (modeStr.includes('ship') || modeStr.includes('ferry')) return 'Ferry';
    if (modeStr.includes('taxi') || modeStr.includes('cab')) return 'Taxi';
    return mode; // Default with original mode name (no emoji)
}

async function generateAIItinerary() {
    const destination = document.getElementById('aiDestination').value.trim();
    const days = document.getElementById('days').value;
    const interests = document.getElementById('interests').value.trim() || 'general sightseeing';
    
    if (!destination) {
        showError('aiResult', 'Please enter a destination');
        return;
    }

    showLoading('aiResult');

    try {
        const response = await fetch('/api/generate-itinerary', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ destination, days, interests })
        });

        const data = await response.json();
        
        if (response.ok) {
            const escapedResult = data.result.replace(/`/g, '\\`').replace(/\$/g, '\\$');
            document.getElementById('aiResult').innerHTML = `
                <div class="result-box">${data.result}</div>
                <button class="btn btn-secondary" style="margin-top: var(--space-16);" 
                        onclick="saveAIItinerary('${destination}', ${days}, \`${escapedResult}\`)">
                    💾 Save This Itinerary
                </button>
            `;
        } else {
            showError('aiResult', data.error || 'Failed to generate itinerary');
        }
    } catch (error) {
        showError('aiResult', 'Network error. Please try again.');
    }
}



async function saveAIItinerary(destination, days, aiGenerated) {
    const tripName = `${destination} - ${days} Day Trip`;
    const today = new Date().toISOString().split('T')[0];
    
    try {
        const response = await fetch('/api/itineraries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                tripName, destination, startDate: today, endDate: today, 
                budget: 0, notes: 'AI Generated Itinerary', aiGenerated 
            })
        });

        if (response.ok) {
            alert('✅ Itinerary saved successfully!');
            switchTab('my-trips');
            document.querySelector('[onclick="switchTab(\'my-trips\')"]').click();
            await loadItinerariesFromServer();
        }
    } catch (error) {
        alert('❌ Failed to save itinerary');
    }
}

async function loadItinerariesFromServer() {
    try {
        const response = await fetch('/api/itineraries');
        const serverItineraries = await response.json();
        itineraries = serverItineraries;
        renderItineraries();
        updateStats();
    } catch (error) {
        console.error('Failed to load itineraries from server:', error);
    }
}

init();
